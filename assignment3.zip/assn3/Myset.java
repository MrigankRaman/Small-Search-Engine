import java.util.*;
public class Myset<Item> implements Iterable <Item> 
{
  private node first;
  private node last;
  private int size=0;
  
  private class node
  {
    Item item;
    node next;
  }
  public Boolean IsEmpty()
  {
    return(size==0);
  }
  public Boolean IsMember(Item o)
  {
    if(size==0)
      return(false);
    node i=first;
    while(i!=null)
    {
      if(i.item.equals(o))
        return(true);
      i=i.next;
    }
    return(false);
  }
  public void Insert(Item o)
  {
    if(IsMember(o)==true)
      return;
    node n=new node();
    n.item=o;
    n.next=null;
    if(size==0)
    {
      first=n;
      last=n;
      size++;
    }
    else
    {
    last.next=n;
    last=n;
    size++;
    }
  }
  public void Delete(Item o)
  {
    if(IsMember(o)==true&&IsEmpty()==false)
    {
      if(size==1)
      {
        first=null;
        last=null;
        size--;
      }
      else if(first.item==o)
      {
        first=first.next;
        size--;
      }
      else
      {
      node i=first;
      while(i.next.item!=o)
       i=i.next;
      i.next=i.next.next;
      size--;
      if(size==1)
        last=first;
      }
    }
  }
  public Myset<Item> Union(Myset<Item> a)
  {
     Myset<Item> union=new Myset<Item>();
     node i=first;
     while(i!=null)
     {
       union.Insert(i.item);
       i=i.next;
     }
     i=a.first;
     while(i!=null)
     {
       union.Insert(i.item);
       i=i.next;
     }
     return(union);
   }
  public Myset<Item> Intersection(Myset<Item> a)
  {
    node i=first;
    Myset<Item> intersection=new Myset<Item>();
    while(i!=null)
    {
      node j=a.first;
      while(j!=null)
      {
        if(j.item.equals(i.item))
          intersection.Insert(i.item);
        j=j.next;
      }
      i=i.next;
    }
    return(intersection);
  }
  public Iterator<Item> iterator() { return new ListIterator(); }
 private class ListIterator implements Iterator<Item>
 {
 private node current = first;
 public boolean hasNext() { return current != null; }
 public void remove() { throw new UnsupportedOperationException(); } 
 public Item next()
 {
  if(hasNext()==false)
    throw new NoSuchElementException();
  else
  {
 Item o = current.item;
 current = current.next;
 return o;
  }
 }
 }
 public static void main(String[] args)
 {
    Myset<Integer> q = new Myset<Integer>();
  q.Insert(5);
  q.Insert(6);
  q.Insert(8);
  q.Delete(8);
 // q.removeLast();
 // q.removeFirst();
 // q.removeFirst();
 // q.removeLast();
  System.out.println(q.IsMember(8));
 }
}