import java.util.*;
 //import java.io.*; 
public class MyHashTable
{
  private  MyLinkedList<WordEntry>[] hash;
  public static final int size=101;
  public MyHashTable()
  {
    hash=new MyLinkedList[101];
  }
  private int getHashIndex(String str)
  {
    int x=str.hashCode();
    if(x<=0)
      x=Integer.MAX_VALUE+x;
    return(x%101);
  }
  public int position(String str)
  {
    int x=str.hashCode();
    if(x<=0)
      x=Integer.MAX_VALUE+x;
    return(x%size);
  }
  public void addPositionsForWord(WordEntry w)
  {
    int pos=getHashIndex(w.toString());
    if(hash[pos]==null)
      hash[pos]=new MyLinkedList<WordEntry>();
    hash[pos].insert(w);
  }
  public MyLinkedList<WordEntry>[] table()
  {
    return hash;
  }
}