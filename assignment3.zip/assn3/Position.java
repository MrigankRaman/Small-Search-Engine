import java.util.*;
public class Position
{
  private PageEntry pe;
  private int index;
  public Position(PageEntry p, int wordIndex)
  {
    pe=p;
    index=wordIndex;
  }
  public PageEntry getPageEntry() 
  {
    return pe;
  }
  public int getWordIndex()
  {
    return index;
  }
}