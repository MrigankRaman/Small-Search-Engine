import java.util.*;
public class SearchEngine
{
  InvertedPageIndex i;
  public SearchEngine()
  {
     i=new InvertedPageIndex();
  }
  public void performAction(String actionMessage)
  {
    if(actionMessage.contains("addPage")==true)
    {
      String [] words = actionMessage.split(" ");
      i.addPage(new PageEntry(words[1]));
    }
    else if(actionMessage.contains("queryFindPagesWhichContainWord")==true)
    {
      String [] words = actionMessage.split(" ");
      String w=words[1];
       if(w.equals("C")==false && w.equals("C++")==false)
       w=w.toLowerCase();
      if(w.equals("structures")||w.equals("stacks")||w.equals("applications"))
        w=w.substring(0,w.length()-1);
     
       Myset<PageEntry> result=new Myset<PageEntry>();
        result=i.getPagesWhichContainWord(w);
        if(result.IsEmpty())
          System.out.println("No webpage contains word"+" "+words[1]);
        else
     System.out.println(i.print(w));
    }
    else if(actionMessage.contains("queryFindPositionsOfWordInAPage")==true)
    {
      String [] words = actionMessage.split(" ");
      //String w=words[1];
      String s="";
       String w=words[1];
        if(w.equals("C")==false && w.equals("C++")==false)
       w=w.toLowerCase();
      if(w.equals("structures")||w.equals("stacks")||w.equals("applications"))
        w=w.substring(0,w.length()-1);
     
      PageEntry p=null;
      for (PageEntry k : i.getpages())
        if(k.getname().equals(words[2]))
        p=k;
      if(p!=null && i.getPagesWhichContainWord(w).IsMember(p)==true )
      {
        for(WordEntry we:p.getPageIndex().getWordEntries())
          if(we.toString().equals(w))
        {
          for(Position p1:we.getAllPositionsForThisWord())
            s=s+Integer.toString(p1.getWordIndex())+", ";
        }
        System.out.println(s.substring(0,s.length()-2));
      }
      else if(p==null)
      {
        System.out.println("No webpage "+words[2]+" found");
      }
      else if(i.getPagesWhichContainWord(w).IsMember(p)==false)
        System.out.println("Webpage"+" "+words[2]+" does not contain word "+words[1]);
    }
  } 
}