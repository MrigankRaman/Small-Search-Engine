import java.util.*;
 import java.io.*; 
public class PageEntry
{
  private String name;
  private PageIndex index=new PageIndex();
  private Exceptions e=new Exceptions();
  private int total_words=0;
  public PageEntry(String pageName)
  {
    name=pageName;
    //Scanner sc;
    try {
   FileInputStream fstream = new FileInputStream (pageName);
    Scanner sc = new Scanner ( fstream );
   while (sc.hasNextLine ()){
     String str=sc.nextLine();
     String [] words = str.split("[\\- '<{(.]");
     for (String word : words)
     {
       if(word.length()>0)
       {
       total_words++;
       if(word.equals("C")==false && word.equals("C++")==false)
       word=word.toLowerCase();
       while(word.length()>0&&(e.punc().IsMember(word.substring(word.length()-1,word.length()))))
         word=word.substring(0,word.length()-1);
       while(word.length()>0&&(e.punc().IsMember(word.substring(0,1))))
         word=word.substring(1,word.length());
       if(word.length()==0)
       {total_words--;continue;}
       if(word.equals("structures")||word.equals("stacks")||word.equals("applications"))
        word=word.substring(0,word.length()-1);
       if(!e.connector().IsMember(word))
       {
         Position x=new Position(this,total_words);
         index.addPositionForWord(word,x);
        // System.out.println(word+" "+total_words);
       }
     }
       //System.out.println(word);
     }
 }
   sc.close();
 } catch (FileNotFoundException e) {
 System . out . println (" File not found ");
    } 
 //sc.close();
  }
  public PageIndex getPageIndex()
  {
    return(index);
  }
  public String getname()
  {
    return(name);
  }
  public int totalwords()
  {
    return total_words;
  }
  public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        PageEntry that = (PageEntry) y;
        if(this.name.equals(that.name))
          return true;
        else
          return false;
  }
     
  public static void main(String[] args)
  {
    PageEntry p=new PageEntry("stack_datastructure_wiki");
    System.out.println(p.getTermFrequency("stack"));
    for(WordEntry we :p.getPageIndex().getWordEntries()) {
        if(we.toString().equals("extends")==true)
        {
          for(Position po:we.getAllPositionsForThisWord())
            System.out.println(po.getWordIndex());
        }
        }
  }
  float getTermFrequency(String word)
  {
    WordEntry w=null;
    for(WordEntry we:index.getWordEntries())
      if(we.toString().equals(word))
      w=we;
    if(w==null)
      return 0;
    else
    return((float)w.getAllPositionsForThisWord().size()/(float)total_words);
  }
}