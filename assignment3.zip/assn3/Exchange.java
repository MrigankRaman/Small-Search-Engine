public class Exchange
{
  private Exchange parent=null;
  private ExchangeList child=new ExchangeList();
  private int id;
  public MobilePhoneSet m=new MobilePhoneSet();
  public Exchange(int number)
  {
    id=number;
  }
  public Exchange parent()
  {
    return(parent);
  }
  public int numChildren()
  {
    return(child.size());
  }
  public int data()
  {
    return(id);
  }
  public Exchange child(int i)
  {
   // if(i==0)
      //return this;
   // else
    return(child.item(i+1));
  }
  public Boolean isRoot()
  {
    return(parent==null);
  }
  public ExchangeList children()
  {
    return(child);
  }
  public void makeparent(Exchange a)
  {
    parent=a;
  }
  public void makechild(Exchange a)
  {
    child.insert(a);
    m=m.mobileunion(a.m);
  }
  public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        Exchange that = (Exchange) y;
        int n=this.data();
        if(n==that.data())
          return(true);
        else
          return false;
  }
  public MobilePhoneSet residentSet()
  {
    return(m);
  }
  public RoutingMapTree subtree(int i) 
  {
    RoutingMapTree t= new RoutingMapTree(child(i));
    return(t);
  }
  public boolean isleaf()
  {
    return(child.size()==0);
  }
}