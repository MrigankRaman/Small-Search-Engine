import java.util.*;
public class InvertedPageIndex 
{
 private Myset<PageEntry> pages=new Myset<PageEntry>() ;
 private MyHashTable h=new MyHashTable();
 public void  addPage(PageEntry p)
 {
   pages.Insert(p);
   for(WordEntry wx:p.getPageIndex().getWordEntries())
   {
     h.addPositionsForWord(wx);
   }
 }
 Myset<PageEntry> getPagesWhichContainWord(String str)
 {
   Myset<PageEntry> result=new Myset<PageEntry>();
   int x=h.position(str);
   for(WordEntry wx:h.table()[x])
   {
     if(wx.toString().equals(str))
     {
       for(Position pos:wx.getAllPositionsForThisWord())
         result.Insert(pos.getPageEntry());
     }
   }
   return result;
 }
 public Myset<PageEntry> getpages()
 {
   return pages;
 }
 public String print(String str)
  {
    String s1="";
    Myset<PageEntry> result=new Myset<PageEntry>();
    result=getPagesWhichContainWord(str);
   for(PageEntry i:result)
   s1=s1+i.getname()+", ";
    return(s1.substring(0,s1.length()-2));
  }
 public static void main(String[] args)
 {
   InvertedPageIndex i=new InvertedPageIndex();
   i.addPage(new PageEntry("stack_cprogramming"));
   i.addPage(new PageEntry("stack_datastructure_wiki"));
   i.addPage(new PageEntry("stack_oracle"));
   i.addPage(new PageEntry("stacklighting"));
   i.addPage(new PageEntry("stackmagazine"));
   Myset<PageEntry> result=new Myset<PageEntry>();
   result=i.getPagesWhichContainWord("function");
   for(PageEntry p:result)
     System.out.println(p.getname());
 }
}