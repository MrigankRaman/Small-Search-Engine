import java.util.*;
public class MySort<Sortable extends Comparable<Sortable> >
{
  public ArrayList<Sortable> sortThisList(Myset<Sortable> listOfSortableEntries)
  {
    int n=listOfSortableEntries.size();
    Myset<Sortable> s=listOfSortableEntries;
    Sortable max;
    ArrayList<Sortable> arrli = new ArrayList<Sortable>(n);
    while(!s.IsEmpty())
    {
      max=s.get(1); 
      for(Sortable so:s)
      {
        if(so.compareTo(max)>0)
          max=so;
      }
      arrli.add(max);
      s.Delete(max);
    }
    return arrli;
  }
  public static void main(String[] args)
 {
    MySort<Integer> s =new MySort<Integer>();
    Myset<Integer> q = new Myset<Integer>();
   q.Insert(10); 
  q.Insert(5);
  q.Insert(6);
  q.Insert(8);
  q.Insert(1);
  //q.Delete(8);
 // q.removeLast();
 // q.removeFirst();
 // q.removeFirst();
 // q.removeLast();
  ArrayList<Integer> arrli=s.sortThisList(q);
  for (int i=0; i<arrli.size(); i++) 
            System.out.print(arrli.get(i)+" "); 
 }
}