import java.util.*;
public class Exceptions
{
  private MyLinkedList<String> c = new MyLinkedList<String>();
  private MyLinkedList<String> p = new MyLinkedList<String>();
  public Exceptions()
  {
    c.insert("a");
    c.insert("an");
    c.insert("the");
    c.insert("they");
    c.insert("these");
    c.insert("this");
    c.insert("for");
    c.insert("is");
    c.insert("are");
    c.insert("was");
    c.insert("of");
    c.insert("or");
    c.insert("and");
    c.insert("does");
    c.insert("will");
    c.insert("whose");
    p.insert("{");
    p.insert("}");
    p.insert("[");
    p.insert("]");
    p.insert("<");
    p.insert(">");
    p.insert("=");
    p.insert("(");
    p.insert(")");
    p.insert(".");
    p.insert(",");
    p.insert(";");
    p.insert("'");
    p.insert("?");
    p.insert("#");
    p.insert("\"");
    p.insert("!");
    p.insert(":");
    p.insert("-");
    p.insert(" ");
  }
  public MyLinkedList<String> connector()
  {
    return c;
  }
  MyLinkedList<String> punc()
  {
    return p;
  }
   public static void main(String[] args)
   {
     Exceptions e=new Exceptions();
     System.out.println(("\""));
   }
}