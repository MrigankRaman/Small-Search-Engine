import java.util.*;
public class MyLinkedList <Item> implements Iterable <Item>
{
  private Node first=null;
  private Node last=null;
  int size=0;
  private class Node
  {
     public Item data;
     public Node next;
  }
  public boolean isEmpty()
  {
    return(first==null);
  }
  public Item item(int i)
  {
    if(i>size)
      throw new IllegalArgumentException();
    Node e=first;
    for(int j=0;j<i-1;j++)
      e=e.next;
    return(e.data);
  }
  public void insert(Item e)
  {
   Node n=new Node();
    n.data=e;
    n.next=null;
    if(size==0)
    {
      first=n;
      last=n;
      size++;
    }
    else
    {
    last.next=n;
    last=n;
    size++;
    }
  }
  /*public String printlist()
  {
    if(first==null)
      throw new NoSuchElementException();
    Node temp=first;
    String s="";
    while(temp!=last)
    {
      s=s+Integer.toString(temp.data.data())+", ";
      temp=temp.next;
    }
    s=s+Integer.toString(temp.data.data());
    //System.out.println(" ");
    return s;
  }*/
  public Iterator<Item> iterator() { return new ListIterator(); }
 private class ListIterator implements Iterator<Item>
 {
 private Node current = first;
 public boolean hasNext() { return current != null; }
 public void remove() { throw new UnsupportedOperationException(); } 
 public Item next()
 {
  if(hasNext()==false)
    throw new NoSuchElementException();
  else
  {
 Item o = current.data;
 current = current.next;
 return o;
  }
 }
 }
  public boolean IsMember(Item e)
  {
    if(first==null)
      return false;
    Node n= first;
    while(n!=null)
    {
      if(n.data.equals(e)==true)
        return true;
      n=n.next;
    }
    return false;
  }
  public int size()
  {
    return(size);
  }
  public void Delete(Item o)
  {
    if(IsMember(o)==true&&isEmpty()==false)
    {
      if(size==1)
      {
        first=null;
        last=null;
        size--;
      }
      else if(first.data.equals(o))
      {
        first=first.next;
        size--;
      }
      else
      {
      Node i=first;
      while(i.next.data.equals(o)==false)
       i=i.next;
      i.next=i.next.next;
      size--;
      if(size==1)
        last=first;
      }
    }
  }
  public static void main(String[] args)
 {
  MyLinkedList<Integer> q = new MyLinkedList<Integer>();
  q.insert(5);
  q.insert(6);
  //q.insert(9);
  q.Delete(6);
  //q.removeLast();
  //q.removeFirst();
  //q.removeFirst();
  //q.removeLast();
  System.out.println(q.size());
   for(Integer num : q) {
        System.out.println(num);
 }
}
}