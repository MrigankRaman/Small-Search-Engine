import java.util.*;
public class InvertedPageIndex 
{
 private Myset<PageEntry> pages=new Myset<PageEntry>() ;
 private MyHashTable h=new MyHashTable();
 private int total_pages=0;
 public void  addPage(PageEntry p)
 {
   pages.Insert(p);
   total_pages++;
   p.setinverted(this);
   for(WordEntry wx:p.getPageIndex().getWordEntries())
   {
     h.addPositionsForWord(wx);
   }
 }
 Myset<PageEntry> getPagesWhichContainWord(String str)
 {
   Myset<PageEntry> result=new Myset<PageEntry>();
   int x=h.position(str);
   for(WordEntry wx:h.table()[x])
   {
     if(wx.toString().equals(str))
     {
       for(Position pos:wx.getAllPositionsForThisWord())
         result.Insert(pos.getPageEntry());
     }
   }
   return result;
 }
 public Myset<PageEntry> getpages()
 {
   return pages;
 }
 public float inversedocfreq(String str)
 {
   int c=0;
   String w[]=new String[1];
   w[0]=str;
   for(PageEntry pe:pages)
     if(pe.doescontainoneword(w))
     c++;
    //System.out.println(pages.size());
   return (float)(Math.log((float)pages.size()/(float)(c)));
 }
 public float inversedocfreqphrase(String words[])
 {
	 int c=getPagesWhichContainPhrase(words).size();
	 return (float)(Math.log((float)pages.size()/(float)(c)));
 }
 public Myset<PageEntry>getPagesWhichContainPhrase(String words[])
 {
   Myset<PageEntry> result=new Myset<PageEntry>(); 
   //String words= Arrays.toString(str);
   //words = words.substring(1,words.length()-1).replace(",", "");
   //System.out.println(words);
   for(PageEntry pe:pages)
   {
     if(pe.IsPhraseThere(words)>0)
       result.Insert(pe);
   }
   return result;
 }
 public Myset<SearchResult>getSearchContainPhrase(String words[])
 {
	 Myset<PageEntry> result=new Myset<PageEntry>();
	 result=getPagesWhichContainPhrase(words);
	 Myset<SearchResult> res=new Myset<SearchResult>();
	 for(PageEntry pe:result)
	 {
		 res.Insert(new SearchResult(pe,pe.getRelevanceOfPage(words,true)));
	 }
	 return res;
 }
 public Myset<SearchResult>getSearchWord(String word)
 {
	 Myset<PageEntry> result=new Myset<PageEntry>();
	 result=getPagesWhichContainWord(word);
	 Myset<SearchResult> res=new Myset<SearchResult>();
	 for(PageEntry pe:result)
	 {
		 res.Insert(new SearchResult(pe,pe.getrelevance(word)));
	 }
	 return res;
 }
 public Myset<SearchResult>getSearchAnd(String words[])
 {
	 Myset<PageEntry> result=new Myset<PageEntry>();
	 for(PageEntry pe:pages)
   {
     if(pe.doescontainallwords(words))
       result.Insert(pe);
   }
    Myset<SearchResult> res=new Myset<SearchResult>();
	for(PageEntry pe:result)
	 {
		 res.Insert(new SearchResult(pe,pe.getRelevanceOfPage(words,false)));
	 }
	 return res;
 }
 public Myset<SearchResult>getSearchOr(String words[])
 {
	 Myset<PageEntry> result=new Myset<PageEntry>();
	 for(PageEntry pe:pages)
   {
     if(pe.doescontainoneword(words))
       result.Insert(pe);
   }
    Myset<SearchResult> res=new Myset<SearchResult>();
	for(PageEntry pe:result)
	 {
		 res.Insert(new SearchResult(pe,pe.getRelevanceOfPage(words,false)));
	 }
	 return res;
 }
 public String print(String str)
  {
    String s1="";
    Myset<PageEntry> result=new Myset<PageEntry>();
    result=getPagesWhichContainWord(str);
   for(PageEntry i:result)
   s1=s1+i.getname()+", ";
    return(s1.substring(0,s1.length()-2));
  }
  public int totalpages()
  {
	  return total_pages;
  }
 public static void main(String[] args)
 {
   InvertedPageIndex i=new InvertedPageIndex();
   i.addPage(new PageEntry("stack_cprogramming"));
   i.addPage(new PageEntry("stack_datastructure_wiki"));
   i.addPage(new PageEntry("stack_oracle"));
   i.addPage(new PageEntry("stacklighting"));
   i.addPage(new PageEntry("stackmagazine"));
   Myset<SearchResult> result=new Myset<SearchResult>();
   String words[]=("stack putumeow").split(" "); 
   result=i.getSearchAnd(words);
   MySort s=new MySort();
   ArrayList<SearchResult> arrli=new ArrayList<SearchResult>();
   arrli=s.sortThisList(result);
   //System.out.println(i.inversedocfreq("putumeow"));
   for(SearchResult p:arrli)
     System.out.println(p.getPageEntry().getname()+" "+p.getRelevance());
 }
}