import java.util.*;
public class Position
{
  private PageEntry pe;
  private int index;
  private int fakeindex;
  public Position(PageEntry p, int wordIndex,int findex)
  {
    pe=p;
    index=wordIndex;
    fakeindex=findex;
  }
  public PageEntry getPageEntry() 
  {
    return pe;
  }
  public int getWordIndex()
  {
    return index;
  }
  public int getFakeindex()
  {
    return fakeindex;
  }
}