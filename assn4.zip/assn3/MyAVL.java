import java.util.*;
public class MyAVL 
{
  private Node root;
  private class Node
  {
    Position data;
    Node left;
    Node right;
    int height;
    public Node(Position key, int height) {
            this.data = key;
            this.height = height;
        }
  }
  public MyAVL()
  {
     root=null;
  }
  public MyAVL( MyLinkedList<Position> p)
  {
    for(Position pos:p)
      put(pos);
  }
  public boolean Isempty()
  {
    return root==null;
  }
  public void put(MyLinkedList<Position> p)
  {
     for(Position pos:p)
      put(pos);
  }
   public void put(Position p) {
        if (p == null) throw new IllegalArgumentException("first argument to put() is null");
        root = put(root, p);
        assert check();
    }
   private Node put(Node x,Position key) {
        if (x == null) return new Node(key, 0);
        int cmp = key.getFakeindex()-x.data.getFakeindex();
        if (cmp < 0) {
            x.left = put(x.left, key);
        }
        else if (cmp > 0) {
            x.right = put(x.right, key);
        }
        else {
            x.data = key;
            return x;
        }
        x.height = 1 + Math.max(height(x.left), height(x.right));
        return balance(x);
    }
 public int height(Node x)
 {
   if(x==null)
     return -1;
   else
     return x.height;
 }
  private int balanceFactor(Node x) {
        return height(x.left) - height(x.right);
    }
  private Node balance(Node x) {
        if (balanceFactor(x) < -1) {
            if (balanceFactor(x.right) > 0) {
                x.right = rotateRight(x.right);
            }
            x = rotateLeft(x);
        }
        else if (balanceFactor(x) > 1) {
            if (balanceFactor(x.left) < 0) {
                x.left = rotateLeft(x.left);
            }
            x = rotateRight(x);
        }
        return x;
    }
  private Node rotateRight(Node x) {
        Node y = x.left;
        x.left = y.right;
        y.right = x;
        x.height = 1 + Math.max(height(x.left), height(x.right));
        y.height = 1 + Math.max(height(y.left), height(y.right));
        return y;
  }
   private Node rotateLeft(Node x) {
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        x.height = 1 + Math.max(height(x.left), height(x.right));
        y.height = 1 + Math.max(height(y.left), height(y.right));
        return y;
    }
   private boolean isAVL() {
        return isAVL(root);
    }
  private boolean isAVL(Node x) {
        if (x == null) return true;
        int bf = balanceFactor(x);
        if (bf > 1 || bf < -1) return false;
        return isAVL(x.left) && isAVL(x.right);
    }
 private boolean isBST() {
        return isBST(root, null, null);
    }
 private boolean isBST(Node x, Position min, Position max) {
        if (x == null) return true;
        if (min != null && (x.data.getFakeindex()-min.getFakeindex()) <= 0) return false;
        if (max != null && (x.data.getFakeindex()-max.getFakeindex()) >= 0) return false;
        return isBST(x.left, min, x.data) && isBST(x.right, x.data, max);
    }
  public boolean search(int key)
  {
   Node x=root;
   while(x!=null)
   {
     int cmp = key-x.data.getFakeindex();
     if(cmp==0)
       return true;
     else if(cmp<0)
       x=x.left;
     else if(cmp>0)
       x=x.right;
   }
   return false;
  }
   private boolean check() {
        if (!isBST()) System.out.println("Symmetric order not consistent");
        if (!isAVL()) System.out.println("AVL property not consistent");
        //if (!isSizeConsistent()) StdOut.println("Subtree counts not consistent");
        //if (!isRankConsistent()) StdOut.println("Ranks not consistent");
        return isBST() && isAVL();
    }
}