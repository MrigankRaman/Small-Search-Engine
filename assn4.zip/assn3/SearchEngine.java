import java.util.*;
public class SearchEngine
{
  InvertedPageIndex i;
  public SearchEngine()
  {
     i=new InvertedPageIndex();
  }
  public void performAction(String actionMessage)
  {
    if(actionMessage.contains("addPage")==true)
    {
      String [] words = actionMessage.split(" ");
      i.addPage(new PageEntry(words[1]));
    }
    else if(actionMessage.contains("queryFindPagesWhichContainWord")==true)
    {
      String [] words = actionMessage.split(" ");
      String w=words[1];
       if(w.equals("C")==false && w.equals("C++")==false)
       w=w.toLowerCase();
      if(w.equals("structures")||w.equals("stacks")||w.equals("applications"))
        w=w.substring(0,w.length()-1);
     
       Myset<PageEntry> result=new Myset<PageEntry>();
        result=i.getPagesWhichContainWord(w);
        if(result.IsEmpty())
          System.out.println("No webpage contains word"+" "+words[1]);
        else
		{
			Myset<SearchResult> res=i.getSearchWord(w);
			MySort s=new MySort();
		ArrayList<SearchResult> arrli=new ArrayList<SearchResult>();
		arrli=s.sortThisList(res);
		String s1="";
		for(SearchResult i:arrli)
        s1=s1+i.getPageEntry().getname()+", ";
         System.out.println(s1.substring(0,s1.length()-2));
		}
    }
    else if(actionMessage.contains("queryFindPositionsOfWordInAPage")==true)
    {
      String [] words = actionMessage.split(" ");
      //String w=words[1];
      String s="";
      String w=words[1];
        if(w.equals("C")==false && w.equals("C++")==false)
       w=w.toLowerCase();
      if(w.equals("structures")||w.equals("stacks")||w.equals("applications"))
        w=w.substring(0,w.length()-1);
     
      PageEntry p=null;
      for (PageEntry k : i.getpages())
        if(k.getname().equals(words[2]))
        p=k;
      if(p!=null && i.getPagesWhichContainWord(w).IsMember(p)==true )
      {
        for(WordEntry we:p.getPageIndex().getWordEntries())
          if(we.toString().equals(w))
        {
          for(Position p1:we.getAllPositionsForThisWord())
            s=s+Integer.toString(p1.getWordIndex())+", ";
        }
        System.out.println(s.substring(0,s.length()-2));
      }
      else if(p==null)
      {
        System.out.println("No webpage "+words[2]+" found");
      }
      else if(i.getPagesWhichContainWord(w).IsMember(p)==false)
        System.out.println("Webpage"+" "+words[2]+" does not contain word "+words[1]);
    }
	 else if(actionMessage.contains("queryFindPagesWhichContainAllWords")==true)
	 {
		String [] w1 = actionMessage.substring(35,actionMessage.length()).split(" "); 
		String []words=w1;
		for(int i=0;i<words.length;i++)
		{
			if(words[i].equals("C")==false && words[i].equals("C++")==false)
              words[i]=words[i].toLowerCase();
            if(words[i].equals("structures")||words[i].equals("stacks")||words[i].equals("applications"))
              words[i]=words[i].substring(0,words[i].length()-1);
		}
		Myset<SearchResult> res=i.getSearchAnd(words);
		if(res.IsEmpty()==false)
		{
		MySort s=new MySort();
		ArrayList<SearchResult> arrli=new ArrayList<SearchResult>();
		arrli=s.sortThisList(res);
		String s1="";
		for(SearchResult i:arrli)
        s1=s1+i.getPageEntry().getname()+", ";
         System.out.println(s1.substring(0,s1.length()-2));
		}
		else
		{
			String w2= Arrays.toString(w1);
            w2 = w2.substring(1,w2.length()-1).replace(",", "");
			System.out.println("No Webpage contains all words "+w2);
		}
	 }
	 else if(actionMessage.contains("queryFindPagesWhichContainAnyOfTheseWords")==true)
	 {
		 String [] word = actionMessage.split(" ");
		 String [] w1 = actionMessage.substring(word[0].length()+1,actionMessage.length()).split(" "); 
		 String []words=w1;
		for(int i=0;i<words.length;i++)
		{
			if(words[i].equals("C")==false && words[i].equals("C++")==false)
              words[i]=words[i].toLowerCase();
            if(words[i].equals("structures")||words[i].equals("stacks")||words[i].equals("applications"))
              words[i]=words[i].substring(0,words[i].length()-1);
		}
		Myset<SearchResult> res=i.getSearchOr(words);
		if(res.IsEmpty()==false)
		{
		MySort s=new MySort();
		ArrayList<SearchResult> arrli=new ArrayList<SearchResult>();
		arrli=s.sortThisList(res);
		String s1="";
		for(SearchResult i:arrli)
        s1=s1+i.getPageEntry().getname()+", ";
         System.out.println(s1.substring(0,s1.length()-2));
		}
		else
		{
			String w2= Arrays.toString(w1);
            w2 = w2.substring(1,w2.length()-1).replace(",", "");
			System.out.println("No Webpage contains any of these words "+w2);
		}
	 }
	 else if(actionMessage.contains("queryFindPagesWhichContainPhrase")==true)
	 {
		 String [] word = actionMessage.split(" ");
		 String [] w1 = actionMessage.substring(word[0].length()+1,actionMessage.length()).split(" "); 
		 String []words=w1;
		for(int i=0;i<words.length;i++)
		{
			if(words[i].equals("C")==false && words[i].equals("C++")==false)
              words[i]=words[i].toLowerCase();
            if(words[i].equals("structures")||words[i].equals("stacks")||words[i].equals("applications"))
              words[i]=words[i].substring(0,words[i].length()-1);
		}
		Myset<SearchResult> res=i.getSearchContainPhrase(words);
		if(res.IsEmpty()==false)
		{
		MySort s=new MySort();
		ArrayList<SearchResult> arrli=new ArrayList<SearchResult>();
		arrli=s.sortThisList(res);
		String s1="";
		for(SearchResult i:arrli)
		{
        s1=s1+i.getPageEntry().getname()+", ";
		}
         System.out.println(s1.substring(0,s1.length()-2));
		}
		else
		{
			String w2= Arrays.toString(w1);
            w2 = w2.substring(1,w2.length()-1).replace(",", "");
			System.out.println("No Webpage contains the phrase "+w2);
		}
	 }
  } 
}