import java.util.*;
public class WordEntry
{
  private String word;
  private MyLinkedList<Position> p=new MyLinkedList<Position> ();
  private MyAVL tree=new MyAVL();
  public WordEntry(String w)
  {
    word=w;
  }
 public void addPosition(Position position)
 {
   p.insert(position);
   tree.put(position);
 }
 public void addPositions(MyLinkedList<Position> positions)
 {
   p=positions;
   tree.put(positions);
 }
 public MyLinkedList<Position> getAllPositionsForThisWord()
 {
   return p;
 }
public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        WordEntry that = (WordEntry) y;
        if(this.word.equals(that.word))
          return true;
        else
          return false;
  }
public String toString()
{
  return word;
}
public MyAVL get_tree()
{
  return tree;
}
}