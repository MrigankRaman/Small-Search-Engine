import java.util.*;
public class PageIndex
{
 private MyLinkedList<WordEntry> w=new MyLinkedList<WordEntry>();
  public void addPositionForWord(String str, Position p)
  {
    WordEntry x=null;
    for(WordEntry we : w) {
        if(we.toString().equals(str)==true)
          x=we;
        }
     if(x==null)
     {
       WordEntry y=new WordEntry(str);
       y.addPosition(p);
       w.insert(y);
     }
     else
     {
       x.addPosition(p);
     }
    }
  public MyLinkedList<WordEntry> getWordEntries()
  {
    return w;
  }
}